from pathlib import Path
import subprocess, sys, os, hashlib, json
p = Path(__file__).parent
os.chdir(p)
env = dict(os.environ, PYTHONIOENCODING='utf-8')
cases = {
    'original_list': ('task_manager_original.py', '1\nКупить хлеб\n1\nСделать ДЗ\n1\nПогулять\n2\n6\n'),
    'original_abc_3': ('task_manager_original.py', '3\nabc\n'),
    'original_abc_4': ('task_manager_original.py', '4\nabc\n'),
    'fixed_full_menu': ('task_manager.py', '1\nКупить хлеб\n1\nСделать ДЗ\n1\nПогулять\n2\n3\n1\n3\n2\n3\n3\n3\nabc\n4\nabc\n4\n2\n4\n999\n5\n2\n6\n'),
}
results = {}
for name, (script, data) in cases.items():
    run = subprocess.run([sys.executable, script], input=data, capture_output=True, encoding='utf-8', env=env)
    (p/f'run_{name}.txt').write_text('Ввод:\n'+data+'\nВывод:\n'+run.stdout+'\nSTDERR:\n'+run.stderr, encoding='utf-8')
    results[name] = run.returncode
    if name.startswith('original_abc'):
        assert run.returncode != 0 and 'ValueError' in run.stderr
    else:
        assert run.returncode == 0
    if name == 'original_list':
        assert 'ID: 1 |' in run.stdout and 'ID: 2 |' in run.stdout and 'ID: 3 |' not in run.stdout
    if name == 'fixed_full_menu':
        assert all(f'ID: {i} |' in run.stdout for i in (1,2,3))
        assert run.stdout.count('Ошибка: ID задачи должен быть целым числом.') == 2
        assert 'INFO' in run.stderr and 'ERROR' in run.stderr
        assert 'Удалено задач: 2' in run.stdout
import contextlib, io
import task_manager_original as original
with contextlib.redirect_stdout(io.StringIO()):
    original.tasks.clear()
    for title in ('A','B','C'): original.add_task(title)
    original.delete_task(2)
    original.add_task('D')
    duplicate_ids = [t['id'] for t in original.tasks]
    original.tasks.clear()
    original.add_task('   ')
    blank_count = len(original.tasks)
assert duplicate_ids == [1,3,3] and blank_count == 1
results['original_duplicate_ids'] = duplicate_ids
results['original_whitespace_title_count'] = blank_count
results['original_sha256_unchanged'] = hashlib.sha256((p/'task_manager_original.py').read_bytes()).hexdigest() == (p/'original_sha256.txt').read_text()
assert results['original_sha256_unchanged']
(p/'verification_final.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
