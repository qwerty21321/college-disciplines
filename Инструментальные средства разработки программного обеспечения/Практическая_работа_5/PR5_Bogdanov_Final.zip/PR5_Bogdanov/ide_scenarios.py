"""Сценарии запускаются в Python Debugger VS Code. Исходник не изменяется."""
import task_manager_original as original
import task_manager_debug_print as printf
import task_manager_debug_delete as deletion
import task_manager as fixed
from unittest.mock import patch

titles = ('Купить хлеб', 'Сделать ДЗ', 'Погулять')
print('\n=== Ошибка границы цикла: временные print ===')
for title in titles:
    printf.add_task(title)
printf.list_tasks()
print('\n=== ID и индекс: breakpoint в исходнике ===')
for title in titles:
    original.add_task(title)
for task_id in (1, 2, 3):
    try:
        original.mark_task_done(task_id)
    except IndexError as error:
        print(f'ID={task_id}: {type(error).__name__}: {error}')
    print('Состояние:', original.tasks)
print('\n=== abc в исходном меню ===')
for branch in ('3', '4'):
    try:
        with patch('builtins.input', side_effect=[branch, 'abc']):
            original.main()
    except ValueError as error:
        print(f'Пункт {branch}, abc: {type(error).__name__}: {error}')
print('\n=== Соседние выполненные задачи: старое удаление ===')
for title in (*titles, 'Четвёртая задача'):
    deletion.add_task(title)
deletion.mark_task_done(1)
deletion.mark_task_done(2)
deletion.delete_completed_tasks()
print('После ошибочного удаления:', deletion.tasks)
print('\n=== Исправленная программа ===')
for title in titles:
    fixed.add_task(title)
fixed.list_tasks()
for task_id in (1, 2, 3):
    fixed.mark_task_done(task_id)
    print('После ID', task_id, ':', [(t['id'], t['done']) for t in fixed.tasks])
with patch('builtins.input', side_effect=['3', 'abc', '4', 'abc', '6']):
    fixed.main()
fixed.tasks.clear()
fixed.next_id = 1
for title in (*titles, 'Четвёртая задача'):
    fixed.add_task(title)
fixed.mark_task_done(1)
fixed.mark_task_done(2)
fixed.delete_completed_tasks()
fixed.list_tasks()
fixed.delete_task(3)
fixed.delete_task(999)
print('СЦЕНАРИИ ЗАВЕРШЕНЫ')
