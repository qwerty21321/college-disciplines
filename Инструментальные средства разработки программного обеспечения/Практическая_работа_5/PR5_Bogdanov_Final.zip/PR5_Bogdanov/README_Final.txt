Практическая работа №5. Итоговая версия
Богданов Роман Романович, ИС-41

PR5_Bogdanov_Final.pdf — обновлённый отчёт, 19 страниц.
screenshots/ — 14 оригинальных снимков видимого VS Code под Windows.
Тринадцать снимков включены в отчёт с пояснениями; ID 3 перед шагом — дополнительный снимок.
task_manager_original.py — исходник преподавателя без изменений (SHA-256 проверен).
task_manager.py — исправленный код, менять его по результатам проверки не потребовалось.
test_task_manager.py — существующие тесты: 9/9 OK.

Запуск программы: python task_manager.py
Проверки: python -m unittest -v test_task_manager.py
Полные сценарии stdin и дополнительные эксперименты: python verify_final.py
IDE: открыть эту папку в VS Code, выбрать конфигурацию «PR5: реальные ошибки».
Поставить breakpoint в task_manager_original.py:29 и task_manager_debug_delete.py:50.
F5 — запуск/продолжение, F10 — шаг. Variables → Globals → tasks показывает список.
Для остановки на IndexError включить Raised Exceptions; затем выключить для остальных проверок.
ide_scenarios.py — сценарий; ide_evidence.py — короткие повторные эксперименты для Debug Console.
Ввод меню в IDE подставлялся через mock.patch; обычный ввод stdin также проверен отдельно.

task_manager_debug_print.py — копия исходника с временными print.
task_manager_debug_delete.py — копия с исправленным поиском ID, но старым удалением.
test_results_final.txt, debug_windows_final.txt, run_*.txt — новые протоколы.
verification_final.json, pdf_validation.json — результаты автоматических проверок.
screenshots_manifest.json — контрольные суммы оригинальных PNG.
build_final_report.py — воспроизводимая сборка PDF (ReportLab, PyMuPDF, Pillow).
prepare_final.py — подготовка копий, уже выполнена; повторять для просмотра не требуется.
ui.ps1 — использованный захват настоящего рабочего стола и управление окном VS Code.

Исходный PR5_Bogdanov_Report.pdf и прежние debug_*.txt сохранены в папке проекта.
В архив включён старый отчёт как источник титульного листа для повторной сборки.
Файлы не публиковались на GitHub/GitLab. Коммитов и push не было.
Все запрошенные локальные проверки выполнены. Отдельных выдуманных снимков нет.
