param([string]$Keys='', [string]$Shot='', [int]$X=0, [int]$Y=0, [int]$ToX=0, [int]$ToY=0, [string]$Text='')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System; using System.Runtime.InteropServices;
public class PR5Window {
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int n);
[DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
[DllImport("user32.dll")] public static extern void mouse_event(uint f,uint x,uint y,uint d,UIntPtr e);
}
'@
$win = Get-Process Code | Where-Object {$_.MainWindowTitle -like '*PR5_Bogdanov*'} | Select-Object -First 1
if (!$win) { throw 'PR5 VS Code window not found' }
[PR5Window]::ShowWindow($win.MainWindowHandle,3) | Out-Null
[PR5Window]::SetForegroundWindow($win.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds 500
if ($X) { [PR5Window]::SetCursorPos($X,$Y) | Out-Null; [PR5Window]::mouse_event(2,0,0,0,[UIntPtr]::Zero); if ($ToX) { Start-Sleep -Milliseconds 200; [PR5Window]::SetCursorPos($ToX,$ToY) | Out-Null; Start-Sleep -Milliseconds 200 }; [PR5Window]::mouse_event(4,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 300 }
if ($Keys) { foreach ($key in $Keys.Split('|')) { [System.Windows.Forms.SendKeys]::SendWait($key); Start-Sleep -Milliseconds 900 } }
if ($Text) { [System.Windows.Forms.Clipboard]::SetText($Text); [System.Windows.Forms.SendKeys]::SendWait('^v'); [System.Windows.Forms.SendKeys]::SendWait('{ENTER}'); Start-Sleep -Milliseconds 700 }
if ($Shot) {
 $b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds
 $bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height
 $g=[System.Drawing.Graphics]::FromImage($bmp)
 $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size)
 $bmp.Save((Join-Path $PSScriptRoot "screenshots\$Shot.png"))
 $g.Dispose(); $bmp.Dispose()
}
