from pathlib import Path
import json, hashlib
p=Path(__file__).parent
original=(p/'task_manager_original.py').read_bytes()
(p/'original_sha256.txt').write_text(hashlib.sha256(original).hexdigest(),encoding='utf-8')
s=original.decode('utf-8')
s=s.replace('for i in range(len(tasks) - 1):', 'print(f"DEBUG len(tasks)={len(tasks)}")\n    for i in range(len(tasks) - 1):\n        print(f"DEBUG i={i}, len(tasks)={len(tasks)}")')
(p/'task_manager_debug_print.py').write_text(s,encoding='utf-8')
s=original.decode('utf-8')
a=s.index('def mark_task_done('); b=s.index('def delete_task(',a)
fixed=(p/'task_manager.py').read_text(encoding='utf-8')
fa=fixed.index('def mark_task_done('); fb=fixed.index('def delete_task(',fa)
s=s[:a]+fixed[fa:fb]+s[b:]
(p/'task_manager_debug_delete.py').write_text(s,encoding='utf-8')
(p/'.vscode').mkdir(exist_ok=True)
(p/'.vscode'/'launch.json').write_text(json.dumps({'version':'0.2.0','configurations':[{'name':'PR5: реальные ошибки','type':'debugpy','request':'launch','program':'${workspaceFolder}/ide_scenarios.py','console':'internalConsole','justMyCode':True,'env':{'PYTHONIOENCODING':'utf-8'}}]},ensure_ascii=False,indent=2),encoding='utf-8')
(p/'.vscode'/'settings.json').write_text(json.dumps({'editor.fontSize':18,'debug.console.fontSize':17,'window.zoomLevel':1,'workbench.startupEditor':'none','security.workspace.trust.enabled':False,'python.defaultInterpreterPath':__import__('sys').executable},indent=2),encoding='utf-8')
