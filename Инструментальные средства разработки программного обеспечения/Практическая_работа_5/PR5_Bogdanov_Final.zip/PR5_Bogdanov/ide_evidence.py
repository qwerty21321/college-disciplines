"""Короткие повторные эксперименты для Debug Console VS Code."""
from unittest.mock import patch
import contextlib
import io
import task_manager_original as original
import task_manager as fixed

def invalid():
    for branch in ('3', '4'):
        try:
            with patch('builtins.input', side_effect=[branch, 'abc']):
                with contextlib.redirect_stdout(io.StringIO()):
                    original.main()
        except ValueError as error:
            print(f'Исходник, пункт {branch}, abc: {type(error).__name__}: {error}')
    with patch('builtins.input', side_effect=['3', 'abc', '4', 'abc', '6']):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            fixed.main()
    lines = buffer.getvalue().splitlines()
    print('\n'.join(line for line in lines if line.startswith('Ошибка:') or line == 'Выход.'))
    assert buffer.getvalue().count('Ошибка: ID') == 2
    print('После двух abc исправленная программа дошла до штатного выхода.')

def corrected():
    fixed.tasks.clear()
    fixed.next_id = 1
    for title in ('Купить хлеб', 'Сделать ДЗ', 'Погулять'):
        fixed.add_task(title)
    fixed.list_tasks()
    for task_id in (1, 2, 3):
        fixed.mark_task_done(task_id)
        print([(task['id'], task['done']) for task in fixed.tasks])

def removal():
    fixed.tasks.clear()
    fixed.next_id = 1
    for title in ('A', 'B', 'C', 'D'):
        fixed.add_task(title)
    fixed.mark_task_done(1)
    fixed.mark_task_done(2)
    fixed.delete_completed_tasks()
    print('Остались ID:', [task['id'] for task in fixed.tasks])
    assert [task['id'] for task in fixed.tasks] == [3, 4]
    fixed.delete_task(3)
    fixed.delete_task(999)
