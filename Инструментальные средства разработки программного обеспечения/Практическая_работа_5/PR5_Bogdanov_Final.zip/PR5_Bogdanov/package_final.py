from pathlib import Path
import json, hashlib, zipfile
from datetime import datetime
import pymupdf
p=Path(__file__).parent
keep={'01_id1_before','02_id1_after','03_id2_before','04_id2_after','05_id3_before','06_indexerror','07_delete_before','08_delete_shift','09_delete_skip','11_printf','12_abc','13_fixed_ids','14_fixed_delete_logs','16_tests'}
# Удаляются только временные пробные снимки, созданные в этой доработке.
for path in (p/'screenshots').glob('*.png'):
    if path.stem not in keep: path.unlink()
probe=p/'screen_probe.png'
if probe.exists(): probe.unlink()
assert len(list((p/'screenshots').glob('*.png')))==14
assert hashlib.sha256((p/'task_manager_original.py').read_bytes()).hexdigest()==(p/'original_sha256.txt').read_text()
readme='''Практическая работа №5. Итоговая версия
Богданов Роман Романович, ИС-41

PR5_Bogdanov_Final.pdf — обновлённый отчёт, 19 страниц.
screenshots/ — 14 оригинальных снимков видимого VS Code под Windows.
Тринадцать снимков включены в отчёт с пояснениями; ID 3 перед шагом — дополнительный снимок.
task_manager_original.py — исходник преподавателя без изменений (SHA-256 проверен).
task_manager.py — исправленный код, менять его по результатам проверки не потребовалось.
test_task_manager.py — существующие тесты: 9/9 OK.

Запуск программы: python task_manager.py
Проверки: python -m unittest -v test_task_manager.py
Полные сценарии stdin и дополнительные эксперименты: python verify_final.py
IDE: открыть эту папку в VS Code, выбрать конфигурацию «PR5: реальные ошибки».
Поставить breakpoint в task_manager_original.py:29 и task_manager_debug_delete.py:50.
F5 — запуск/продолжение, F10 — шаг. Variables → Globals → tasks показывает список.
Для остановки на IndexError включить Raised Exceptions; затем выключить для остальных проверок.
ide_scenarios.py — сценарий; ide_evidence.py — короткие повторные эксперименты для Debug Console.
Ввод меню в IDE подставлялся через mock.patch; обычный ввод stdin также проверен отдельно.

task_manager_debug_print.py — копия исходника с временными print.
task_manager_debug_delete.py — копия с исправленным поиском ID, но старым удалением.
test_results_final.txt, debug_windows_final.txt, run_*.txt — новые протоколы.
verification_final.json, pdf_validation.json — результаты автоматических проверок.
screenshots_manifest.json — контрольные суммы оригинальных PNG.
build_final_report.py — воспроизводимая сборка PDF (ReportLab, PyMuPDF, Pillow).
prepare_final.py — подготовка копий, уже выполнена; повторять для просмотра не требуется.
ui.ps1 — использованный захват настоящего рабочего стола и управление окном VS Code.

Исходный PR5_Bogdanov_Report.pdf и прежние debug_*.txt сохранены в папке проекта.
В архив включён старый отчёт как источник титульного листа для повторной сборки.
Файлы не публиковались на GitHub/GitLab. Коммитов и push не было.
Все запрошенные локальные проверки выполнены. Отдельных выдуманных снимков нет.
'''
(p/'README_Final.txt').write_text(readme,encoding='utf-8')
manifest={path.name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'source':'Windows CopyFromScreen; visible VS Code window; unmodified original PNG'} for path in sorted((p/'screenshots').glob('*.png'))}
(p/'screenshots_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
files=['PR5_Bogdanov_Final.pdf','PR5_Bogdanov_Report.pdf','task_manager_original.py','task_manager.py','test_task_manager.py','task_manager_debug_print.py','task_manager_debug_delete.py','ide_scenarios.py','ide_evidence.py','verify_final.py','build_final_report.py','prepare_final.py','package_final.py','ui.ps1','README_Final.txt','original_sha256.txt','test_results_final.txt','debug_windows_final.txt','verification_final.json','pdf_validation.json','screenshots_manifest.json','.vscode/launch.json','.vscode/settings.json']
files += [x.name for x in sorted(p.glob('run_*.txt'))]
files += ['screenshots/'+path.name for path in sorted((p/'screenshots').glob('*.png'))]
archive=p/'PR5_Bogdanov_Final.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name in files: z.write(p/name,'PR5_Bogdanov/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(files)==len(set(names))
    for name in files:
        assert z.read('PR5_Bogdanov/'+name)==(p/name).read_bytes(),name
    assert sum('/screenshots/' in name for name in names)==14
    for required in ('PR5_Bogdanov_Final.pdf','task_manager.py','task_manager_original.py','test_task_manager.py'):
        assert 'PR5_Bogdanov/'+required in names
with pymupdf.open(p/'PR5_Bogdanov_Final.pdf') as doc:
    pages=len(doc)
    assert pages==19
    assert sum(len(page.get_images()) for page in doc)==13
result={'pdf_pages':pages,'screenshots':14,'embedded_screenshots':13,'zip_entries':len(files),'zip_crc':'OK','zip_contents_match_files':True,'original_unchanged':True,'zip_bytes':archive.stat().st_size}
(p/'final_check.txt').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
