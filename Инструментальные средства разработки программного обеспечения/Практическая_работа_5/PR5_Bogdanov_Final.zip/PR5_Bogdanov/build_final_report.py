from pathlib import Path
from io import BytesIO
from xml.sax.saxutils import escape
import json, hashlib, zipfile
import pymupdf
from PIL import Image, ImageOps, ImageDraw
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.lib.pagesizes import A4, landscape

p = Path(__file__).parent
pdfmetrics.registerFont(TTFont('ArialPR5', 'C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('ArialBoldPR5', 'C:/Windows/Fonts/arialbd.ttf'))
pdfmetrics.registerFont(TTFont('CodePR5', 'C:/Windows/Fonts/consola.ttf'))
style = ParagraphStyle('body', fontName='ArialPR5', fontSize=11, leading=15, spaceAfter=10)
small = ParagraphStyle('small', fontName='ArialPR5', fontSize=10, leading=13)
stream = BytesIO()
c = canvas.Canvas(stream, pagesize=A4)
c.setTitle('Практическая работа №5 — Богданов Роман Романович, ИС-41')
c.setAuthor('Богданов Роман Романович')
page_num = 2

def header(title, wide=False):
    global W,H
    W,H = landscape(A4) if wide else A4
    c.setPageSize((W,H))
    c.setFont('ArialBoldPR5', 15)
    c.drawString(35,H-40,title)
    return H-65

def para(text, y, font_style=style):
    q = Paragraph(escape(text),font_style)
    _,h = q.wrap(W-70,H)
    q.drawOn(c,35,y-h)
    return y-h-10

def end():
    global page_num
    c.setFont('ArialPR5',9)
    c.drawRightString(W-35,20,str(page_num))
    c.showPage()
    page_num += 1

y=header('1. Цель, среда и порядок проверки')
for text in [
    'Цель: найти причины ошибок в менеджере задач, проверить гипотезы экспериментами и подтвердить исправления.',
    'Работа выполнена в Windows 10, Python 3.14, Visual Studio Code 1.146. Установлены расширения ms-python.python и ms-python.debugpy. Использованы реальные точки останова, шаг F10, продолжение F5, панели Variables и Debug Console.',
    'task_manager_original.py сохранён без изменений. Для временной печати создан task_manager_debug_print.py. В task_manager_debug_delete.py исправлен только поиск в mark_task_done; функция delete_completed_tasks оставлена ошибочной. Контрольная сумма исходника записана в original_sha256.txt и повторно проверена.',
    'Сценарий ide_scenarios.py запускается конфигурацией .vscode/launch.json. Точки останова установлены в исходнике на строке 29 и в копии для удаления на строке 50. Для IndexError включалась остановка Raised Exceptions. На снимках видны код, текущая строка, переменные и стек вызовов.',
    'Ввод для повторяемых экспериментов в IDE подаётся через unittest.mock.patch: значения 3, abc, 4, abc, 6 возвращаются функцией input. Это запуск настоящих веток меню. Отдельно программы запущены обычными процессами с тем же вводом через stdin; протоколы run_*.txt приложены.',
    'Короткие повторные эксперименты ide_evidence.py вызваны из Debug Console во время остановки сценария удаления. Поэтому на снимках результатов исправленной программы слева может оставаться состояние остановленной копии для удаления; вывод справа получен вызовами исправленного модуля task_manager.',
    'Снимки получены захватом видимого рабочего стола Windows через CopyFromScreen. Они не рисовались и не заменялись текстовыми протоколами. В папке screenshots сохранены оригинальные PNG; в PDF часть снимков обрезана по краям для чтения. Старые debug_*.txt сохранены как предыдущие материалы, а доказательства текущего запуска находятся в новых снимках и протоколах.',
    'Исправленный код уже содержал необходимые изменения. Новых ошибок в нём при проверках не найдено, поэтому он и существующие тесты сохранены. Публикация в GitHub/GitLab, коммиты и push не выполнялись.'
]: y=para(text,y)
end()

shots = [
('11_printf','2. Ошибка границы цикла: временная печать',
 'Наблюдение: из трёх задач выводятся две. Гипотеза: цикл не доходит до последнего элемента. Эксперимент: в отдельной копии вывести len(tasks) и i внутри list_tasks. Вывод: длина 3, индексы 0 и 1; range(len(tasks) - 1) не включает индекс 2. Исправление: for task in tasks.',
 'Рис. 1. Debug Console VS Code: len(tasks)=3, i=0 и i=1; «Погулять» не выведена. Верхняя часть окна относится к остановленному сценарию удаления.', (650,690,1910,1005)),
('01_id1_before','3. ID 1: остановка перед присваиванием',
 'Наблюдение: выбранный ID и позиция задачи не совпадают. Гипотеза: ID ошибочно используется как индекс списка. Эксперимент: остановиться перед tasks[task_id]["done"] = True и раскрыть Globals → tasks в Variables. task_id=1, а список содержит индексы 0, 1, 2 и ID 1, 2, 3.',
 'Рис. 2. Реальная точка останова в исходнике, task_id=1 и список задач в Variables.', (60,80,1800,690)),
('02_id1_after','3. ID 1: результат одного шага',
 'Эксперимент: выполнить присваивание клавишей F10. Наблюдение: у элемента с индексом 1, ID 2, done стало True. У ID 1 остаётся False. Вывод: обращение tasks[1] выбирает вторую задачу, а не задачу с ID 1.',
 'Рис. 3. После шага F10 выполнена задача «Сделать ДЗ» с ID 2.', (60,80,1800,690)),
('03_id2_before','3. ID 2: повторная остановка',
 'Эксперимент: продолжить сценарий F5 до следующей остановки. Variables показывает task_id=2. Индекс 2 относится к задаче «Погулять» с ID 3. Это повторно проверяет гипотезу на другом значении ID.',
 'Рис. 4. task_id=2 перед ошибочным обращением к третьему элементу списка.', (60,80,1800,690)),
('04_id2_after','3. ID 2: результат шага',
 'Наблюдение после F10: у задачи с ID 3 стало done=True. Задача ID 1 по-прежнему не выполнена. Вывод: ошибка повторяется, потому что идентификатор принят за позицию. Исправление — искать task["id"] == task_id; вычитание единицы не решает случай после удаления задач.',
 'Рис. 5. После ID 2 изменена задача с ID 3; значения видны в Variables.', (60,80,1800,690)),
('06_indexerror','3. ID 3: исключение IndexError',
 'Эксперимент: при task_id=3 выполнить строку с включённым Raised Exceptions. Наблюдение: IDE остановилась на IndexError: list index out of range. Вывод: при длине 3 допустимы индексы 0, 1, 2; индекса 3 нет. Исключение перехвачено сценарием, чтобы продолжить остальные проверки.',
 'Рис. 6. VS Code показывает IndexError, строку исходника, task_id=3 и длину списка 3.', (60,80,1810,690)),
('07_delete_before','4. Удаление соседних задач: до remove',
 'Наблюдение: из двух соседних выполненных задач удаляется одна. Гипотеза: удаление во время перебора сдвигает список. Эксперимент: в копии с исправленным поиском ID создать четыре задачи и отметить ID 1, 2. Остановка перед tasks.remove(task): текущий task имеет ID 1, обе первые задачи выполнены.',
 'Рис. 7. Variables: список [1, 2, 3, 4], done=True у ID 1 и 2; count=0.', (60,80,1810,690)),
('08_delete_shift','4. Удаление: сдвиг списка после F10',
 'Эксперимент: выполнить remove одним шагом F10. Наблюдение: список стал [2, 3, 4], ID 2 переместился с индекса 1 на индекс 0. Переменная task ещё ссылается на удалённый словарь ID 1. Счётчик count пока равен 0, потому что следующая строка ещё не выполнена.',
 'Рис. 8. После remove в списке остались ID 2, 3, 4; первый из них выполнен.', (60,80,1810,690)),
('09_delete_skip','4. Удаление: второй выполненный элемент пропущен',
 'Эксперимент: выполнить следующие шаги до проверки очередного task. Наблюдение: count=1, текущий task имеет ID 3, хотя ID 2 выполнен и остался в списке. Вывод: итератор перешёл к индексу 1 и пропустил сдвинутый элемент. Исправление — сначала отфильтровать невыполненные задачи, затем заменить tasks[:] новым содержимым.',
 'Рис. 9. Variables: текущий ID 3; ID 2 с done=True остался на позиции 0.', (60,80,1810,690)),
('12_abc','5. Ввод abc: ошибка и обработка',
 'Наблюдение: исходные пункты 3 и 4 вызывают ValueError. Гипотеза: int(input(...)) не защищён обработкой исключения. Эксперимент: подать abc в обе ветки исходника и исправленного меню. Вывод: исходник выдаёт ValueError; исправленный код дважды сообщает об ошибке ID и доходит до штатного выхода. Решение — try/except ValueError и возврат в меню.',
 'Рис. 10. Debug Console: два ValueError исходника и две обработанные ошибки исправленного меню (VS Code свернул одинаковые строки, слева показано 2).', (650,690,1910,1005)),
('13_fixed_ids','6. Исправление: все задачи и правильные ID',
 'Повторная проверка: добавлены «Купить хлеб», «Сделать ДЗ», «Погулять»; показаны все три задачи. Затем последовательно отмечены ID 1, 2, 3. Состояния: [(1, True), (2, False), (3, False)], затем [(1, True), (2, True), (3, False)], затем все True. Вывод: поиск по ID отмечает нужную задачу и не вызывает IndexError.',
 'Рис. 11. Реальный вывод corrected() в Debug Console: список трёх задач и состояния после каждого ID.', (650,440,1910,1005)),
('14_fixed_delete_logs','6. Исправление: удаление и журнал',
 'Повторная проверка: созданы четыре задачи, ID 1 и 2 отмечены выполненными. После фильтрации удалены обе, остаются ID [3, 4]. Удаление ID 3 записано logging.info, попытка удаления ID 999 — logging.error. Вывод: соседние выполненные задачи не пропускаются, уровни журнала соответствуют результату.',
 'Рис. 12. Debug Console: «Удалено задач: 2», оставшиеся ID [3, 4], строки INFO и ERROR.', (650,440,1910,1005)),
('16_tests','7. Автоматические проверки',
 'Команда в терминале VS Code: python -m unittest -v test_task_manager.py. Все 9 существующих тестов прошли, результат OK. Проверяются вывод трёх задач, поиск после удаления, неверные ID, соседние выполненные задачи, abc в обоих пунктах, уровни логирования, уникальность ID, пустое название и граничные случаи пустого списка.',
 'Рис. 13. Настоящий терминал VS Code: Ran 9 tests, OK. Полный текст сохранён в test_results_final.txt.', (650,440,1910,1005)),
]

for filename,title,body,caption,box in shots:
    y=header(title,True)
    y=para(body,y,small)
    im=Image.open(p/'screenshots'/f'{filename}.png').crop(box)
    maxw=W-70
    maxh=y-65
    factor=min(maxw/im.width,maxh/im.height)
    iw,ih=im.width*factor,im.height*factor
    c.drawImage(ImageReader(im),(W-iw)/2,y-ih,width=iw,height=ih)
    para(caption,y-ih-12,small)
    end()

y=header('8. Дополнительные ошибки и ответы')
for text in [
    'Повторение ID. Наблюдение: после удаления ID 2 и добавления новой задачи в исходнике получено [1, 3, 3]. Гипотеза: len(tasks)+1 не обеспечивает уникальность. Эксперимент: добавить три задачи, удалить вторую, добавить ещё одну. Вывод: нужен отдельный next_id. В исправленном коде результат [1, 3, 4]; проверка test_id_not_reused_after_deletion прошла.',
    'Название из пробелов. Наблюдение: исходник принимает строку из трёх пробелов. Гипотеза: непустая строка проходит if not title. Эксперимент: add_task("   ") создаёт одну задачу в исходнике. Вывод: перед проверкой нужно strip(). В исправленном коде задача не создаётся и next_id остаётся 1; тест прошёл.',
    'Почему не видна последняя задача? Верхняя граница range не включается; range(3 - 1) даёт только 0 и 1. Прямой перебор элементов показывает весь список.',
    'Чем ID отличается от индекса? ID — постоянный номер задачи, индекс — её текущее место в списке от нуля. При удалении индексы сдвигаются, а ID оставшихся задач сохраняются.',
    'Почему при удалении исчезла только одна из двух выполненных задач? После remove первого элемента второй сдвинулся на его место, а итератор перешёл вперёд. В результате ID 2 не проверялся повторно. Фильтрация сохраняет только невыполненные элементы и устраняет пропуск.',
    'Что вызывает ValueError? Текст abc нельзя преобразовать в целое число функцией int. except ValueError позволяет сообщить о неверном вводе и продолжить меню.',
    'Зачем нужны logging.info и logging.error? INFO фиксирует успешное удаление, ERROR — отсутствие запрошенного ID. logging.basicConfig задаёт уровень INFO и формат с временем, уровнем и сообщением.',
    'Чем отличаются способы отладки? Временный print быстро показывает значения в цикле. Breakpoint приостанавливает программу, Variables показывает состояние, F10 выполняет одну строку, F5 продолжает до следующей остановки. Логирование оставляет события работы программы с их уровнями.'
]: y=para(text,y)
end()

y=header('9. Итог проверки и состав комплекта')
for text in [
    'Повторный обычный запуск исходника подтвердил пропуск последней задачи; abc в пункте 3 и отдельно в пункте 4 завершает процесс с кодом 1 и ValueError. Исправленная программа прошла полный сценарий меню с кодом 0: показала три задачи, отметила ID 1, 2, 3, обработала оба abc, записала INFO и ERROR, удалила оставшиеся выполненные задачи и завершилась по пункту 6.',
    'Протоколы: run_original_list.txt, run_original_abc_3.txt, run_original_abc_4.txt, run_fixed_full_menu.txt. Проверка verify_final.py также повторила ошибки дублирования ID и названия из пробелов. Результаты записаны в verification_final.json.',
    'Основные файлы: task_manager_original.py — неизменённый исходник; task_manager.py — исправленный код; test_task_manager.py — существующие тесты; две task_manager_debug_*.py — отдельные копии для экспериментов; ide_scenarios.py и ide_evidence.py — сценарии IDE; screenshots — оригинальные снимки Windows; .vscode/launch.json — конфигурация запуска.',
    'Ограничения: ввод в повторяемых IDE-сценариях подставлялся программно, а не набирался вручную. Это указано в описании. Проверка через обычный stdin выполнена отдельно. Изображения в отчёте являются снимками видимого VS Code; текстовые протоколы приведены отдельно и не выдаются за скриншоты.',
    'Вывод: проверены и подтверждены исправления границы цикла, поиска по ID, удаления во время перебора и обработки неверного ввода. Дополнительно проверены уникальность ID и пустые названия. Незавершённых обязательных действий по локальной подготовке нет. Публикация отложена по условию задания.',
    'Титульный лист сохранён из исходного отчёта без изменений. Полный исправленный код далее включён прямо из task_manager.py. Снимки вынесены на широкие страницы, чтобы код и Variables можно было читать при увеличении PDF. Для нового отчёта использованы установленные в ходе работы ReportLab и PyMuPDF.',
    'Предыдущий отчёт указывает источник задания: AlexSkoruk/Novosibirsk-Machine-Building-College, ИСРПО, «Практическая работа №5.docx», версия 96aaf6f от 16.11.2026. В этой доработке исходное задание из сети повторно не сверялось.'
]: y=para(text,y)
end()

lines=(p/'task_manager.py').read_text(encoding='utf-8').splitlines()
for start in range(0,len(lines),52):
    y=header('Приложение. Полный исправленный код'+(' (продолжение)' if start else ''))
    c.setFont('CodePR5',9)
    for line in lines[start:start+52]:
        assert pdfmetrics.stringWidth(line,'CodePR5',9) <= W-70, line
        c.drawString(35,y,line)
        y-=13.7
    end()
c.save()
body=pymupdf.open(stream=stream.getvalue(),filetype='pdf')
final=pymupdf.open()
with pymupdf.open(p/'PR5_Bogdanov_Report.pdf') as source:
    final.insert_pdf(source,from_page=0,to_page=0)
final.insert_pdf(body)
final.set_metadata({'title':'Практическая работа №5. Отладка программных продуктов','author':'Богданов Роман Романович, ИС-41'})
final.save(p/'PR5_Bogdanov_Final.pdf',garbage=4,deflate=True)

# Рендер всех страниц для визуальной проверки.
review=p/'pdf_review'
review.mkdir(exist_ok=True)
checks=[]
with pymupdf.open(p/'PR5_Bogdanov_Final.pdf') as doc:
    for i,page in enumerate(doc):
        pix=page.get_pixmap(matrix=pymupdf.Matrix(1.5,1.5))
        pix.save(review/f'page_{i+1:02}.png')
        text=page.get_text()
        assert text.strip(), i+1
        checks.append({'page':i+1,'width':round(page.rect.width),'height':round(page.rect.height),'text_chars':len(text),'images':len(page.get_images())})
    assert len(doc)==page_num-1
    assert 'Богданов Роман Романович' in doc[0].get_text()
    all_text='\n'.join(pg.get_text() for pg in doc)
    assert 'pdb' not in all_text
    assert all(line.strip() in all_text for line in lines if line.strip())
(p/'pdf_validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
thumbs=[]
for path in sorted(review.glob('page_*.png')):
    im=Image.open(path).convert('RGB')
    im.thumbnail((440,540))
    tile=Image.new('RGB',(460,570),'#cccccc')
    tile.paste(im,((460-im.width)//2,20))
    ImageDraw.Draw(tile).text((10,550),path.stem,fill='black')
    thumbs.append(tile)
for batch in range(0,len(thumbs),6):
    sheet=Image.new('RGB',(1380,1140),'white')
    for n,tile in enumerate(thumbs[batch:batch+6]): sheet.paste(tile,((n%3)*460,(n//3)*570))
    sheet.save(review/f'contact_{batch//6+1}.jpg')

print('PDF pages:',len(checks))
print('Rendered every page; full code, cover and text verified.')
